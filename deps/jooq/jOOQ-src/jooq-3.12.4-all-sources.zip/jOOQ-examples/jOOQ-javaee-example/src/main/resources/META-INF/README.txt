Thanks for downloading jOOQ.
Please visit http://www.jooq.org for more information