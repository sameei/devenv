@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jooq.org/xsd/jooq-codegen-3.12.0.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.jooq.meta.jaxb;
